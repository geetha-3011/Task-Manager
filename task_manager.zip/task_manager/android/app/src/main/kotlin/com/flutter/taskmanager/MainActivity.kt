package com.flutter.taskmanager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
